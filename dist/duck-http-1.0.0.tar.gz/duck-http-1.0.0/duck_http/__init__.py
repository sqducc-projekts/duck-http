"""
:copyright: (c) 2022-present Laith Rafid
:license: MIT, see LICENSE for more details.
"""

__title__ = "duck-http"
__full_title__ = "duck-http"
__author__ = "Laith Rafid"
__license__ = "MIT"
__copyright__ = "Copyright 2022-present Laith Rafid"
__version__ = "0.0.0"