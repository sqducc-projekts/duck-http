# duck-http
duck-http is a high performance, barebones, made-from-scratch, zero-dependency HTTP framework for Python

# Documentation
This is a WIP so nothing's done yet
